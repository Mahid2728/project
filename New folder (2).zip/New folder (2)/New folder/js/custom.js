jQuery(document).ready(function(){

	jQuery(window).scroll(function(){
		// for scrool top
		if(jQuery(window).scrollTop() > 100){
			jQuery('.scrolTop').fadeIn();
		}
		else if(jQuery(window).scrollTop() <= 100){
			jQuery('.scrolTop').fadeOut();
		}


// for fixed menu

		if(jQuery(window).scrollTop() > 0){
			jQuery('.menu-section').addClass("fixed");
		}
		else if(jQuery(window).scrollTop() <= 100){
			jQuery('.menu-section').removeClass("fixed");
		}

	});

	
	
	jQuery('.scrolTop').click(function(){
		jQuery('html, body').animate({scrollTop:0},500, "swing");
		
		return false;
	});


	jQuery('.mob').click(function(){
		jQuery('.menu').toggle(500);
		
		return false;
	});


});